/*
 * author :  Rutvik V Shah
 * This is the basic program to show a basic functionality of servlet with a form request
 */

package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FirstServlet extends HttpServlet {

	public FirstServlet() {
		System.out.println("Constructor is called!");
	}

	@Override
	public void init() throws ServletException {
		System.out.println("Init() is called");
	}

//	@Override
//	protected void service(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		System.out.println("Service is called");
//		System.out.println(request.getParameter("username"));
//		System.out.println(request.getParameter("password"));
//	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("doGet() is called");
		System.out.println("---------Parameter Values--------");
		System.out.println(request.getParameter("username"));
		System.out.println(request.getParameter("password"));
		String countries[] = request.getParameterValues("country");
		for (String c : countries) {
			System.out.println(c);
		}
		System.out.println("---------Parameter Names--------");
		Enumeration<String> enmr = request.getParameterNames();
		while(enmr.hasMoreElements()) {
			System.out.println(enmr.nextElement());
		}
		System.out.println("---------Parameter Names & Values--------");
		Enumeration<String> parameter = request.getParameterNames();
	    PrintWriter out = response.getWriter();
	    response.setContentType("text/html");
		while(parameter.hasMoreElements()) {
			String paramName = parameter.nextElement();
			String paramValue = Arrays.toString(request.getParameterValues(paramName));
			System.out.println(paramName+" : "+paramValue);
			out.println("<table>");
			out.println("<tr>"+"<td>"+paramName+"</td>"+"<td>"+paramValue+"</td>"+"</tr>");
		}
		out.println("</table>");
		
		
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost() is called");
		System.out.println("---------Parameter Values--------");
		System.out.println(request.getParameter("username"));
		System.out.println(request.getParameter("password"));
		String countries[] = request.getParameterValues("country");
		for (String c : countries) {
			System.out.println(c);
		}
		System.out.println("---------Parameter Names--------");
		Enumeration<String> enmr = request.getParameterNames();
		while(enmr.hasMoreElements()) {
			System.out.println(enmr.nextElement());
		}
		System.out.println("---------Parameter Names & Values--------");
		Enumeration<String> parameter = request.getParameterNames();
	    PrintWriter out = response.getWriter();
	    response.setContentType("text/html");
		while(parameter.hasMoreElements()) {
			String paramName = parameter.nextElement();
			String paramValue = Arrays.toString(request.getParameterValues(paramName));
			System.out.println(paramName+" : "+paramValue);
			out.println("<table>");
			out.println("<tr>"+"<td>"+paramName+"</td>"+"<td>"+paramValue+"</td>"+"</tr>");
		}
		out.println("</table>");
	}
	
	@Override
	public void destroy() {
		System.out.println("destroy() is called");
	}

}
